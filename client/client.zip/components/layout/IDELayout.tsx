'use client';

import { useState, ReactNode } from 'react';
import ActivityBar from './ActivityBar';
import Sidebar from './Sidebar';
import StatusBar from './StatusBar';
import Panel from './Panel';
import EditorTabs, { EditorTab } from './EditorTabs';
import AIChatView from '../views/AIChatView';
import ExplorerView, { FileNode } from '../views/ExplorerView';
import SearchView from '../views/SearchView';
import GitView from '../views/GitView';
import MindMapView from '../views/MindMapView';
import SettingsView from '../views/SettingsView';

interface IDELayoutProps {
  children?: ReactNode;
  files?: FileNode[];
  expandedDirs?: Record<string, boolean>;
  onFileClick?: (file: FileNode) => void;
  onDirToggle?: (path: string) => void;
  selectedFile?: FileNode | null;
  tabs?: EditorTab[];
  activeTabId?: string;
  onTabClick?: (tabId: string) => void;
  onTabClose?: (tabId: string) => void;
  showAnalysisPanel?: boolean;
  analysisContent?: string;
  onAnalysisClose?: () => void;
  statusBarProps?: {
    line?: number;
    column?: number;
    language?: string;
    branch?: string;
    aiStatus?: 'idle' | 'processing' | 'ready';
  };
}

export default function IDELayout({
  children,
  files = [],
  expandedDirs = {},
  onFileClick = () => {},
  onDirToggle = () => {},
  selectedFile = null,
  tabs = [],
  activeTabId = '',
  onTabClick = () => {},
  onTabClose = () => {},
  statusBarProps = {}
}: IDELayoutProps) {
  const [activeView, setActiveView] = useState<string>('explorer');
  const [showPanel, setShowPanel] = useState(true);
  const [showSidebar, setShowSidebar] = useState(true);

  const renderSidebarContent = () => {
    switch (activeView) {
      case 'explorer':
        return (
          <ExplorerView
            files={files}
            expandedDirs={expandedDirs}
            onFileClick={onFileClick}
            onDirToggle={onDirToggle}
            selectedFile={selectedFile}
          />
        );
      case 'search':
        return <SearchView />;
      case 'git':
        return <GitView />;
      case 'mindmap':
        return <MindMapView />;
      case 'ai':
        return <AIChatView />;
      case 'extensions':
        return (
          <div className="p-3 text-sm text-[#858585]">
            <div className="text-center py-8 transition-all duration-300 hover:text-[#cccccc] cursor-default">
              Extensions view coming soon
            </div>
          </div>
        );
      case 'settings':
        return <SettingsView />;
      default:
        return null;
    }
  };

  const getSidebarTitle = () => {
    switch (activeView) {
      case 'explorer':
        return 'Explorer';
      case 'search':
        return 'Search';
      case 'git':
        return 'Source Control';
      case 'mindmap':
        return 'Mind Map';
      case 'ai':
        return 'AI Assistant';
      case 'extensions':
        return 'Extensions';
      case 'settings':
        return 'Settings';
      default:
        return '';
    }
  };

  return (
    <div className="h-screen flex flex-col bg-gradient-to-br from-[#1e1e1e] via-[#1a1a1a] to-[#161616] text-[#cccccc] overflow-hidden">
      <style jsx>{`
        @keyframes slideInLeft {
          from {
            transform: translateX(-100%);
            opacity: 0;
          }
          to {
            transform: translateX(0);
            opacity: 1;
          }
        }

        @keyframes slideOutLeft {
          from {
            transform: translateX(0);
            opacity: 1;
          }
          to {
            transform: translateX(-100%);
            opacity: 0;
          }
        }

        @keyframes fadeIn {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }

        @keyframes slideUp {
          from {
            transform: translateY(10px);
            opacity: 0;
          }
          to {
            transform: translateY(0);
            opacity: 1;
          }
        }

        @keyframes slideDown {
          from {
            transform: translateY(-10px);
            opacity: 0;
          }
          to {
            transform: translateY(0);
            opacity: 1;
          }
        }

        .sidebar-enter {
          animation: slideInLeft 0.3s cubic-bezier(0.4, 0, 0.2, 1) forwards;
        }

        .sidebar-exit {
          animation: slideOutLeft 0.3s cubic-bezier(0.4, 0, 0.2, 1) forwards;
        }

        .fade-in {
          animation: fadeIn 0.4s cubic-bezier(0.4, 0, 0.2, 1) forwards;
        }

        .slide-up {
          animation: slideUp 0.3s cubic-bezier(0.4, 0, 0.2, 1) forwards;
        }

        .slide-down {
          animation: slideDown 0.3s cubic-bezier(0.4, 0, 0.2, 1) forwards;
        }

        * {
          transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
        }

        ::-webkit-scrollbar {
          width: 10px;
          height: 10px;
        }

        ::-webkit-scrollbar-track {
          background: rgba(30, 30, 30, 0.3);
          border-radius: 5px;
        }

        ::-webkit-scrollbar-thumb {
          background: rgba(128, 128, 128, 0.4);
          border-radius: 5px;
          transition: background 0.3s ease;
        }

        ::-webkit-scrollbar-thumb:hover {
          background: rgba(128, 128, 128, 0.6);
        }

        @media (prefers-reduced-motion: reduce) {
          * {
            animation-duration: 0.01ms !important;
            animation-iteration-count: 1 !important;
            transition-duration: 0.01ms !important;
          }
        }
      `}</style>

      <div className="flex-1 flex overflow-hidden relative">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black/5 pointer-events-none z-0" />

        <ActivityBar activeView={activeView} onViewChange={setActiveView} />
        
        {showSidebar && (
          <div className="sidebar-enter relative z-10">
            <Sidebar
              title={getSidebarTitle()}
              width={activeView === 'mindmap' ? 400 : activeView === 'ai' ? 350 : 250}
              onClose={() => setShowSidebar(false)}
            >
              <div className="h-full backdrop-blur-sm bg-[#252526]/95 border-r border-[#3e3e42]/50 shadow-xl flex flex-col">
                <div className="h-full overflow-hidden flex-1">
                  <div className="fade-in h-full">
                    {renderSidebarContent()}
                  </div>
                </div>
              </div>
            </Sidebar>
          </div>
        )}

        <div className="flex-1 flex flex-col overflow-hidden relative z-10">
          {tabs.length > 0 && (
            <div className="slide-down">
              <EditorTabs
                tabs={tabs}
                activeTabId={activeTabId}
                onTabClick={onTabClick}
                onTabClose={onTabClose} name={''}              />
            </div>
          )}

          <div className="flex-1 overflow-hidden bg-[#1e1e1e] relative group">
            <div className="absolute inset-0 shadow-inner pointer-events-none opacity-30" />
            
            <div className="h-full w-full relative z-10 transition-all duration-300">
              {children}
            </div>
          </div>

          {showPanel && (
            <div className="slide-up">
              <Panel onClose={() => setShowPanel(false)} />
            </div>
          )}
        </div>
      </div>

      <StatusBar {...statusBarProps} />
    </div>
  );
}
